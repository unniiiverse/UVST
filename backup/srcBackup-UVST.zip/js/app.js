import * as uvstFunctions from './modules/functions.js';

document.addEventListener('DOMContentLoaded', () => {
    uvstFunctions.tabsInit();
})