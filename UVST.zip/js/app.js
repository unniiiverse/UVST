import * as uvstFunctions from './modules/functions.js';

uvstFunctions.isWebp();